let express=require('express');
var bodyParser = require('body-parser');
let fs=require('fs')
let app=express();
let p=require('path');
let usename=new Map();
let cdetails=new Map();



let pa=p.join(__dirname,'../public')
console.log(pa)
let pa1=p.join(__dirname,'../public/login.html')

app.use(express.static(pa));
app.use(bodyParser.urlencoded({ extended: true }))


app.post('/welcome',(req,res)=>{
    let fname=req.body.fname
    let lname=req.body.lname
    let id;
    if(usename.has(fname))
    {
    id= usename.get(fname).indexOf(lname)
    if(id<0)
    {
    usename.get(fname).push(lname) 
    id=usename.get(fname).indexOf(lname)
    }
    }
    else
    {
    usename.set(fname,[]);
    usename.get(fname).push(lname)
    id=0;
    }
    let userid=fname+(id+1);
    if(cdetails.has(userid))
    {
    res.send('This userid is already exit')
    }
    else
    {
    let password=req.body.password
    cdetails.set(userid,[])
    cdetails.get(userid).push(fname)
    cdetails.get(userid).push(lname)
    cdetails.get(userid).push(password)
  
    res.send(fs.readFileSync(pa1).toString())
    }

})

app.post('/open',(req,res)=>{
 let userid= req.body.userid
 let password= req.body.password
 if(cdetails.has(userid))
 {
 let t=cdetails.get(userid).indexOf(password)
 if(t<0)
 {
 res.send('Invalid login')
 }
 else
 {
  res.send('<h1>Welcome '+cdetails.get(userid)[0]+'</h1>')
 }

 }
 else
 {
  res.send('userid not found')
 }
})


app.listen(8000,()=>{
  console.log(`app is created`)  
});