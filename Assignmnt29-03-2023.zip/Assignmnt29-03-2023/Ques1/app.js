let http=require('http')
let url=require('url')
let fs=require('fs');
let day,month,year;

let server=http.createServer((req,res)=>{
    if(req.url==='/')
 res.end(fs.readFileSync('index.html').toString()); 
 else if(req.url.startsWith('/age'))
 {
 let p=url.parse(req.url,true).query
let date=new Date(p.dob);
let actual=date.getTime()
let current=new Date();
current=current.getTime();
current=current-actual
year=(current/(1000*60*60*24*365))
month=(current%(1000*60*60*24*365))
month=month/(1000*60*60*24*30)
day=month%(1000*60*60*24*30)
day=day/(1000*60*60*24)
    res.end('<h1>'+Math.round(year)+' Year' +" " + Math.round(month) +' Month'+" "+ Math.round(day)+' day'+" "+ "</h1>")
 }


 

})


server.listen(8000,()=>{
    console.log('Praduman Gupta')
})
