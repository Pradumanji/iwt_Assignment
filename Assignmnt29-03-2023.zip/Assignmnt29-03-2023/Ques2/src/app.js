let express=require('express');
var bodyParser = require('body-parser');
let app=express();
let p=require('path');
let usename=new Map();


let pa=p.join(__dirname,'../public')
console.log(pa)
app.use(express.static(pa));
app.use(bodyParser.urlencoded({ extended: true }))


app.post('/welcome',(req,res)=>{
    let fname=req.body.fname
    let lname=req.body.lname
    let id;
    if(usename.has(fname))
    {
    id= usename.get(fname).indexOf(lname)
    if(id<0)
    {
    usename.get(fname).push(lname) 
    id=usename.get(fname).indexOf(lname)
    }
    }
    else
    {
    usename.set(fname,[]);
    usename.get(fname).push(lname)
    id=0;
    }
    res.send('<h1>'+'Welcome '+fname+' '+lname+'Your user id is '+fname+'.'+(id+1)+'</h1>')
})


app.listen(8000,()=>{
  console.log(`app is created`)  
});